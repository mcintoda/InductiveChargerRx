G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*
G04 #@! TF.CreationDate,2026-11-24T02:45:17+00:00*
G04 #@! TF.ProjectId,bath_monitor,62617468-5f6d-46f6-9e69-746f722e6b69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-11-24 02:45:17*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,0.500000*%
%ADD11RoundRect,0.250000X0.550000X0.550000X-0.550000X0.550000X-0.550000X-0.550000X0.550000X-0.550000X0*%
%ADD12C,1.600000*%
%ADD13C,0.650000*%
%ADD14O,1.600000X1.000000*%
%ADD15O,2.100000X1.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,#MB2*
X138000000Y-60900000D03*
G04 #@! TD*
G04 #@! TO.C,#MB4*
X138000000Y-70900000D03*
G04 #@! TD*
G04 #@! TO.C,#MB3*
X138000000Y-70100000D03*
G04 #@! TD*
G04 #@! TO.C,#MB5*
X138000000Y-64300000D03*
G04 #@! TD*
G04 #@! TO.C,#MB6*
X138000000Y-66870000D03*
G04 #@! TD*
G04 #@! TO.C,#MB1*
X138000000Y-60100000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,L1*
X105600000Y-77000000D03*
D12*
X102000000Y-77000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J2*
X147760000Y-62610000D03*
X147760000Y-68390000D03*
D14*
X151410000Y-61180000D03*
D15*
X147230000Y-61180000D03*
D14*
X151410000Y-69820000D03*
D15*
X147230000Y-69820000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X136400000Y-77000000D03*
D12*
X132800000Y-77000000D03*
G04 #@! TD*
M02*
